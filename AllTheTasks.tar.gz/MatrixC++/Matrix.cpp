
#include <stdlib.h>

using namespace std;
int main(){
    cout<<"hello "<< endl;
    return EXIT_SUCCESS;
}