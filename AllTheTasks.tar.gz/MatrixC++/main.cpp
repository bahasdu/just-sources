/* 
 * File:   main.cpp
 * Author: baha
 *
 * Created on October 20, 2012, 9:08 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

