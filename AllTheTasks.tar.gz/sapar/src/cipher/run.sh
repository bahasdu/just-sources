java -cp  /home/baha/NetBeansProjects/sapar/dist/Manaspayev.jar cipher.VigenerCipher
