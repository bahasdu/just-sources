/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sequential;

/**
 *
 * @author 16817
 */
public class ClientProcessor implements Runnable{
    public boolean finished=false;
    public ClientProcessor(){
        
    }
    public void run() {
        
    }

}
